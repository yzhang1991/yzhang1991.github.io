In order to use the .bat file:


1. Save the folder "Sample Test Cases" to your computer.

2. Copy your executable file to the folder.

3. Double-click on the file Test.bat. This will execute your program with the 5 test cases provided.

4. Compare your output to the screenshot provided.

5. DON'T GET COMPLACENT. REMEMBER TO CREATE YOUR OWN TEST CASES AND TRY TO ACCOUNT FOR ALL EVENTUALITIES.