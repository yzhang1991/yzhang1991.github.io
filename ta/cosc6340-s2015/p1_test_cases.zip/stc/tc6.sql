SELECT * FROM airports2 WHERE astate='TX'
EXIT
