INSERT INTO airports2 (3, "AK", "AFM", "Ambler Airport", "bla bla bla")
EXIT
