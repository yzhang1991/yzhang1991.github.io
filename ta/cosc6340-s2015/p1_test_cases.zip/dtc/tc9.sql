SELECT acode, aname FROM airports123
EXIT
