SELECT * FROM states, airports1 WHERE sabbr=astate
EXIT
