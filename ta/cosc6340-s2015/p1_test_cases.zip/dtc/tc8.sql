CREATE error (a, b, c)
EXIT
