SELECT acode, aname FROM airports1
EXIT
